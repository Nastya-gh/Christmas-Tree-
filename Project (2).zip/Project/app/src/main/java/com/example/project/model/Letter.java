package com.example.project.model;

import androidx.room.Entity;
import androidx.room.PrimaryKey;
import androidx.room.TypeConverters;

import com.example.project.converter.UriConverters;

import org.jetbrains.annotations.NotNull;

import java.util.List;

@Entity
public class Letter {
    @PrimaryKey
    @NotNull
    public String name;
    public String organizationName;
    public Long date;
    public String text;
    public String number;
    @TypeConverters({UriConverters.class})
    public List<String> images;
    public boolean isFavourite;


    public Letter(@NotNull String name, String organizationName, Long date, String text, String number, List<String> images, boolean isFavourite) {
        this.name = name;
        this.organizationName = organizationName;
        this.date = date;
        this.text = text;
        this.number = number;
        this.images = images;
        this.isFavourite = isFavourite;
    }
}
