package com.example.project.screens.org;

import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

import com.example.project.MainActivity;
import com.example.project.R;
import com.example.project.enums.State;
import com.example.project.model.Organization;
import com.google.android.material.textfield.TextInputLayout;
import com.screen_manager.Screen;

import org.osmdroid.util.GeoPoint;

import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.observers.DisposableCompletableObserver;
import io.reactivex.schedulers.Schedulers;
import ru.tinkoff.decoro.MaskImpl;
import ru.tinkoff.decoro.slots.PredefinedSlots;
import ru.tinkoff.decoro.watchers.FormatWatcher;
import ru.tinkoff.decoro.watchers.MaskFormatWatcher;

public class OrgScreen extends Screen {
    private final EditText name;
    private final EditText phoneNumber;
    MainActivity a = (MainActivity) activity;
    private Organization organization;
    EditText address;
    private GeoPoint geoPoint;

    public void setAddress(String address, GeoPoint geoPoint) {
        this.address.setText(address);
        this.geoPoint = geoPoint;
    }

    public OrgScreen(ViewGroup parent) {
        super(parent, R.layout.add_org_screen);
        MaskImpl mask = MaskImpl.createTerminated(PredefinedSlots.RUS_PHONE_NUMBER);
        mask.setHideHardcodedHead(true);
        FormatWatcher formatWatcher = new MaskFormatWatcher(mask);

        ImageView map_address = view.findViewById(R.id.map_address);
        map_address.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                a.mapScreen.state = State.SELECT_POINT;
                a.manager.setScreen(a.mapScreen);

            }
        });

        name = view.findViewById(R.id.oraganizator_name);
        address = view.findViewById(R.id.organizator_adress);
        phoneNumber = view.findViewById(R.id.number);
        formatWatcher.installOn(phoneNumber);
        Button ok = view.findViewById(R.id.ok);
        ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isValid()) {
                    if (organization == null) {
                        organization = new Organization("admin", "admin", name.getText().toString(), phoneNumber.getText().toString(), address.getText().toString(), geoPoint.getLatitude(), geoPoint.getLongitude());
                        a.db.getOrgDao().insert(organization).subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).subscribe(new DisposableCompletableObserver() {

                            @Override
                            public void onError(Throwable t) {
                                Log.i("RxJava", t.toString());
                            }

                            @Override
                            public void onComplete() {
                                a.manager.setScreen(a.letterScreen);
                            }
                        });
                    }

                }
            }
        });
    }

    private boolean isValid() {
        EditText phoneNumber = view.findViewById(R.id.number);
        TextInputLayout t = view.findViewById(R.id.containerNumber);
        if (phoneNumber.getText().toString().length() == 18) {
            t.setError(null);
            return (true);
        } else {
            t.setError("Ошибка");
            return (false);
        }
    }

public void updateOrg(){
    organization = null;
    name.setText("");
    address.setText("");
    phoneNumber.setText("");
}
    @Override
    protected void releaseData() {
        super.releaseData();
        a.setTitle("Регистрация организатора");
    }
}
