package com.example.project.screens.fav;

import android.view.ViewGroup;

import androidx.recyclerview.widget.RecyclerView;

import com.example.project.MainActivity;
import com.example.project.R;
import com.example.project.adapter.LetterAdapter;
import com.example.project.model.Letter;
import com.screen_manager.Screen;

import java.util.ArrayList;

import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.Disposable;
import io.reactivex.schedulers.Schedulers;

public class FavoriteScreen extends Screen {
    MainActivity a = (MainActivity) activity;
    private RecyclerView recyclerView;
    private LetterAdapter letterAdapter;

    public FavoriteScreen(ViewGroup parent) {
        super(parent, R.layout.favorite_screen);
        recyclerView = view.findViewById(R.id.recycler_view);
        letterAdapter = new LetterAdapter(new ArrayList<>(), v -> {
            int position = recyclerView.getChildAdapterPosition(v);
            Letter l = letterAdapter.letters.get(position);
            a.favoriteLetterScreen.letter = l;
            a.manager.setScreen(a.favoriteLetterScreen);
        }, a);
        recyclerView.setAdapter(letterAdapter);
    }

    private void updateAll() {
        Disposable s = a.db.getLetterDao().getAllLetter().subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).subscribe(l -> {
            letters = (ArrayList<Letter>) l;
            letters.removeIf(e -> !e.isFavourite);
            updateList();
            letterAdapter.notifyDataSetChanged();

        });
    }

    private ArrayList<Letter> letters = new ArrayList<>();

    public void updateList() {
        letterAdapter.letters = letters;
    }

    @Override
    protected void releaseData() {
        super.releaseData();
        MainActivity a = (MainActivity) activity;
        a.setTitle("Избранное");
        updateAll();
    }
}
