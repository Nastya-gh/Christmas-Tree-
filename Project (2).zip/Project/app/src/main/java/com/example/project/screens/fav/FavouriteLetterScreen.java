package com.example.project.screens.fav;

import android.graphics.Bitmap;
import android.net.Uri;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.example.project.MainActivity;
import com.example.project.R;
import com.example.project.model.Letter;
import com.google.android.material.textfield.TextInputLayout;
import com.screen_manager.Screen;

import java.io.IOException;
import java.util.ArrayList;

public class FavouriteLetterScreen extends Screen {
    private final EditText nameOfPresent;
    private final EditText letterText;
    private final TextView date;
    private final TextView phoneNumber;
    MainActivity a = (MainActivity) activity;
    ArrayList<Uri> images = new ArrayList<>();
    public Letter letter;

    public FavouriteLetterScreen(ViewGroup parent) {
        super(parent, R.layout.favourite_letter_screen);
        nameOfPresent = view.findViewById(R.id.edit_text);
        letterText = view.findViewById(R.id.letter_text);
        date = view.findViewById(R.id.date);
        phoneNumber = view.findViewById(R.id.number);
    }

    private ArrayList<String> listToString(ArrayList<Uri> images) {
        ArrayList<String> result = new ArrayList<>();
        for (int i = 0; i < images.size(); i++) {
            result.add(images.get(i).getPath());
        }
        return result;
    }

    private boolean isValid() {
        EditText phoneNumber = view.findViewById(R.id.number);
        TextInputLayout t = view.findViewById(R.id.containerNumber);
        if (phoneNumber.getText().toString().length() == 18) {
            t.setError(null);
            return (true);
        } else {
            t.setError("Ошибка");
            return (false);
        }
    }

    public void addImage(Uri uri) {
        images.add(uri);
        inflateImage(uri);
    }

    public void inflateImage(Uri uri) {
        LinearLayout add_image_cont = view.findViewById(R.id.add_image_cont);
        try {
            Bitmap bitmap = MediaStore.Images.Media.getBitmap(a.getContentResolver(), uri);
            View view = a.getLayoutInflater().inflate(R.layout.img, add_image_cont, false);
            add_image_cont.addView(view, 0);
            ImageView img = (ImageView) view;
            img.setImageBitmap(bitmap);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void releaseData() {
        super.releaseData();
        a.setTitle("Письмо");
        LinearLayout add_image_cont = view.findViewById(R.id.add_image_cont);
        for (int i = 0; i < add_image_cont.getChildCount(); i++) {
            if (add_image_cont.getChildAt(i).getId() != R.id.add_image) {
                add_image_cont.removeViewAt(i);
            }
        }
        if (letter != null) {
            for (int i = 0; i < letter.images.size(); i++) {
                Uri uri = Uri.parse(letter.images.get(i));
                Log.i("uri", uri.toString());
                inflateImage(uri);
            }
            nameOfPresent.setText(letter.name);
            letterText.setText(letter.text);
            date.setText(a.dateFormat.format(letter.date));
            phoneNumber.setText(letter.number);
        }
    }
}
