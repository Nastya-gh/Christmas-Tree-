package com.example.project.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.project.MainActivity;
import com.example.project.R;
import com.example.project.model.Letter;

import java.util.ArrayList;

import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.schedulers.Schedulers;

public class LetterAdapter extends RecyclerView.Adapter<LetterAdapter.MyViewHolder> {
    public ArrayList<Letter> letters;
    View.OnClickListener onClickListener;
    MainActivity a;

    public LetterAdapter(ArrayList<Letter> letters, View.OnClickListener onClickListener, MainActivity a) {
        this.letters = letters;
        this.onClickListener = onClickListener;
        this.a = a;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new MyViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.item_letter, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        Letter letter = letters.get(position);
        if (letter != null) {
            holder.letterContent.setText(letter.name);
            MainActivity a = (MainActivity) holder.itemView.getContext();
            holder.letterDate.setText(a.dateFormat.format(letter.date));
            holder.itemView.setOnClickListener(onClickListener);
            holder.star.setOnClickListener(e -> {
                letter.isFavourite = !letter.isFavourite;
                if (letter.isFavourite) {
                    holder.star.setImageResource(R.drawable.ic_star);
                } else {
                    holder.star.setImageResource(R.drawable.ic_star_border);
                }
                a.db.getLetterDao().update(letter).observeOn(AndroidSchedulers.mainThread()).subscribeOn(Schedulers.io()).subscribe();
            });
            if (letter.isFavourite) {
                holder.star.setImageResource(R.drawable.ic_star);
            } else {
                holder.star.setImageResource(R.drawable.ic_star_border);
            }

        }
    }

    @Override
    public int getItemCount() {
        return letters.size();
    }

    static class MyViewHolder extends RecyclerView.ViewHolder {
        TextView letterContent;
        TextView letterDate;
        ImageView star;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            letterContent = itemView.findViewById(R.id.letter_content);
            letterDate = itemView.findViewById(R.id.letter_date);
            star = itemView.findViewById(R.id.star);
        }
    }

}
