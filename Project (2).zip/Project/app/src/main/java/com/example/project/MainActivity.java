package com.example.project;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.room.Room;

import com.example.project.db.AppDatabase;
import com.example.project.enums.State;
import com.example.project.screens.fav.FavoriteScreen;
import com.example.project.screens.fav.FavouriteLetterScreen;
import com.example.project.screens.letter.LetterScreen;
import com.example.project.screens.letter.LettersScreen;
import com.example.project.screens.letter.NewLetterScreen;
import com.example.project.screens.map.MapScreen;
import com.example.project.screens.org.OrgScreen;
import com.screen_manager.Screen;
import com.screen_manager.ScreenManager;

import org.osmdroid.config.Configuration;
import org.osmdroid.views.MapView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    public ArrayList<LinearLayout> list = new ArrayList<>();
    ArrayList<Screen> screenList = new ArrayList<>();
    public ScreenManager manager;
    public LetterScreen letterScreen;
    public MapScreen mapScreen;
    public FavoriteScreen favoriteScreen;
    public NewLetterScreen newLetterScreen;
    public FavouriteLetterScreen favoriteLetterScreen;
    public OrgScreen orgScreen;
    public LettersScreen lettersScreen;
    public AppDatabase db;


    public SimpleDateFormat dateFormat = (SimpleDateFormat) SimpleDateFormat.getDateInstance();
    public static final int GALLERY_REQUEST = 1;

    private final int REQUEST_PERMISSIONS_REQUEST_CODE = 2;
    private MapView map = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Context ctx = getApplicationContext();
        Configuration.getInstance().load(ctx, PreferenceManager.getDefaultSharedPreferences(ctx));
        setContentView(R.layout.activity_main);

        db = Room.databaseBuilder(getApplicationContext(),
                AppDatabase.class, "my_db").build();

        dateFormat.applyPattern("dd-MM-yyyy");
        LinearLayout letter = findViewById(R.id.letter);
        LinearLayout gift = findViewById(R.id.gift);
        LinearLayout favorite = findViewById(R.id.favorite);
        list.add(letter);
        list.add(favorite);
        list.add(gift);
        for (final LinearLayout it : list) {
            it.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    releaseAll();
                    ImageView icon = (ImageView) it.getChildAt(0);
                    icon.getDrawable().setTint(getResources().getColor(R.color.color_active));
                    TextView text = (TextView) it.getChildAt(1);
                    text.setTextColor(getResources().getColor(R.color.color_active));
                    int index = list.indexOf(it);
                    if (screenList.get(index) == mapScreen) {
                        mapScreen.state = State.SELECT_ORG;
                    }
                    manager.setScreen(screenList.get(index));
                }
            });
        }
        ViewGroup root = findViewById(R.id.root);
        letterScreen = new LetterScreen(root);
        favoriteScreen = new FavoriteScreen(root);
        mapScreen = new MapScreen(root);
        map = mapScreen.map;
        newLetterScreen = new NewLetterScreen(root);
        favoriteLetterScreen = new FavouriteLetterScreen(root);
        orgScreen = new OrgScreen(root);
        lettersScreen = new LettersScreen(root);
        screenList.add(letterScreen);
        screenList.add(favoriteScreen);
        screenList.add(mapScreen);
        manager = new ScreenManager(letterScreen, this);
        manager.setScreen(letterScreen);
        requestPermissionsIfNecessary(new String[]{
                Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.WRITE_EXTERNAL_STORAGE
        });
    }

    public void startImagePicker() {
        Intent photoPickerIntent = new Intent(Intent.ACTION_PICK);
        photoPickerIntent.setType("image/*");
        startActivityForResult(photoPickerIntent, GALLERY_REQUEST);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent imageReturnedIntent) {
        super.onActivityResult(requestCode, resultCode, imageReturnedIntent);


        switch (requestCode) {
            case GALLERY_REQUEST:
                if (resultCode == RESULT_OK) {
                    Uri selectedImage = imageReturnedIntent.getData();
                    newLetterScreen.addImage(selectedImage);
                    Log.i("uri",selectedImage.toString());
                }
        }
    }

    void releaseAll() {
        for (LinearLayout it : list) {
            ImageView icon = (ImageView) it.getChildAt(0);
            icon.getDrawable().setTint(getResources().getColor(R.color.color_white));
            TextView text = (TextView) it.getChildAt(1);
            text.setTextColor(getResources().getColor(R.color.color_white));
        }
    }

    public void setTitle(String s) {
        TextView text = findViewById(R.id.title);
        text.setText(s);
    }

    public void setTitle(int s) {
        TextView text = findViewById(R.id.title);
        text.setText(s);
    }

    @Override
    public void onResume() {
        super.onResume();
        //this will refresh the osmdroid configuration on resuming.
        //if you make changes to the configuration, use
        //SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this);
        //Configuration.getInstance().load(this, PreferenceManager.getDefaultSharedPreferences(this));
        map.onResume(); //needed for compass, my location overlays, v6.0.0 and up
    }

    @Override
    public void onPause() {
        super.onPause();
        //this will refresh the osmdroid configuration on resuming.
        //if you make changes to the configuration, use
        //SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this);
        //Configuration.getInstance().save(this, prefs);
        map.onPause();  //needed for compass, my location overlays, v6.0.0 and up
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        ArrayList<String> permissionsToRequest = new ArrayList<>();
        for (int i = 0; i < grantResults.length; i++) {
            permissionsToRequest.add(permissions[i]);
        }
        if (permissionsToRequest.size() > 0) {
            ActivityCompat.requestPermissions(
                    this,
                    permissionsToRequest.toArray(new String[0]),
                    REQUEST_PERMISSIONS_REQUEST_CODE);
        }
    }

    private void requestPermissionsIfNecessary(String[] permissions) {
        ArrayList<String> permissionsToRequest = new ArrayList<>();
        for (String permission : permissions) {
            if (ContextCompat.checkSelfPermission(this, permission)
                    != PackageManager.PERMISSION_GRANTED) {
                // Permission is not granted
                permissionsToRequest.add(permission);
            }
        }
        if (permissionsToRequest.size() > 0) {
            ActivityCompat.requestPermissions(
                    this,
                    permissionsToRequest.toArray(new String[0]),
                    REQUEST_PERMISSIONS_REQUEST_CODE);
        }
    }

    @Override
    public void onBackPressed() {
        if (manager.currentScreen == orgScreen) {
            super.onBackPressed();
        } else {
            mapScreen.state = State.SELECT_ORG;
            manager.onBackPressed();
        }
    }
}
