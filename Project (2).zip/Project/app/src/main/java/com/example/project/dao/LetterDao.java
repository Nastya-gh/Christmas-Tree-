package com.example.project.dao;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import com.example.project.model.Letter;

import java.util.List;

import io.reactivex.Completable;
import io.reactivex.Flowable;

@Dao
public interface LetterDao {

    // Добавление Letter в бд
    @Insert
    Completable insert(Letter letter);

    // Удаление Letter из бд
    @Delete
    void delete(Letter letter);

    // Получение всех Letter из бд
    @Query("SELECT * FROM letter")
    Flowable<List<Letter>> getAllLetter();

    @Update
    Completable update(Letter letter);

}

