package com.example.project.converter;

import androidx.room.TypeConverter;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class UriConverters {

    @TypeConverter
    public String fromList(List<String> hobbies) {
        return hobbies.stream().collect(Collectors.joining(","));
    }

    @TypeConverter
    public List<String> toList(String data) {
        return Arrays.asList(data.split(","));
    }

}

