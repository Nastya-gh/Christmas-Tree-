package com.example.project.screens.letter;

import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;

import com.example.project.MainActivity;
import com.example.project.R;
import com.example.project.enums.State;
import com.screen_manager.Screen;

public class LetterScreen extends Screen {
    public LetterScreen(ViewGroup parent) {
        super(parent, R.layout.letter_screen);
    }

    MainActivity a = (MainActivity) activity;
    private ImageView v1;
    private Button v2;

    @Override
    protected void show() {
        super.show();
        v1 = view.findViewById(R.id.v1);
        v2 = view.findViewById(R.id.v2);
        v1.setOnClickListener(v -> {
            a.mapScreen.state = State.SELECT_POINT;
            a.manager.setScreen(a.mapScreen);
            a.list.get(2).callOnClick();
        });
        v2.setOnClickListener(v -> {
            a.orgScreen.updateOrg();
            a.manager.setScreen(a.orgScreen);
        });

    }

    @Override
    protected void releaseData() {
        super.releaseData();
        a.setTitle("Выберите роль");
    }

}
