package com.example.project.enums;

public enum State {
    SELECT_POINT, SELECT_ORG, NONE
}
