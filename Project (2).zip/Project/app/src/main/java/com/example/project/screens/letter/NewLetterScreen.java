package com.example.project.screens.letter;

import android.graphics.Bitmap;
import android.net.Uri;
import android.provider.MediaStore;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.example.project.MainActivity;
import com.example.project.R;
import com.example.project.model.Letter;
import com.google.android.material.textfield.TextInputLayout;
import com.msa.dateedittext.DateEditText;
import com.screen_manager.Screen;

import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;

import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.Disposable;
import io.reactivex.functions.Action;
import io.reactivex.schedulers.Schedulers;
import ru.tinkoff.decoro.MaskImpl;
import ru.tinkoff.decoro.slots.PredefinedSlots;
import ru.tinkoff.decoro.watchers.FormatWatcher;
import ru.tinkoff.decoro.watchers.MaskFormatWatcher;

public class NewLetterScreen extends Screen {
    MainActivity a = (MainActivity) activity;
    ArrayList<Uri> images = new ArrayList<>();
    public Letter letter;

    public NewLetterScreen(ViewGroup parent) {
        super(parent, R.layout.add_letter_screen);
        MaskImpl mask = MaskImpl.createTerminated(PredefinedSlots.RUS_PHONE_NUMBER);
        mask.setHideHardcodedHead(true);
        FormatWatcher formatWatcher = new MaskFormatWatcher(mask);


        final EditText nameOfPresent = view.findViewById(R.id.edit_text);
        final EditText letterText = view.findViewById(R.id.letter_text);
        final DateEditText date = view.findViewById(R.id.date);
        date.listen();
        final EditText phoneNumber = view.findViewById(R.id.number);
        formatWatcher.installOn(phoneNumber);
        Button ok = view.findViewById(R.id.ok);
        ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isValid()) {
                    try {
                        if (letter == null) {

                            final Letter letter = new Letter(
                                    nameOfPresent.getText().toString(),
                                    a.lettersScreen.getOrganizator().getName(),
                                    a.dateFormat.parse(date.getText().toString()).getTime(),
                                    letterText.getText().toString(),
                                    phoneNumber.getText().toString(),
                                    listToString(images), false);
                            Disposable s = a.db.getLetterDao().insert(letter).subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).subscribe(new Action() {
                                @Override
                                public void run() {
                                    a.manager.setScreen(a.lettersScreen);
                                }
                            });
                        } else {
                            letter.name = nameOfPresent.getText().toString();
                            letter.date = a.dateFormat.parse(date.getText().toString()).getTime();
                            letter.text = letterText.getText().toString();
                            letter.number = phoneNumber.getText().toString();
                            letter.images = listToString(images);
                        }
                    } catch (ParseException e) {
                        e.printStackTrace();
                    }
                }
            }
        });
        View add_image = view.findViewById(R.id.add_image);
        add_image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                a.startImagePicker();

            }
        });
    }

    private ArrayList<String> listToString(ArrayList<Uri> images) {
        ArrayList<String> result = new ArrayList<>();
        for (int i = 0; i < images.size(); i++) {
            result.add(images.get(i).toString());
        }
        return result;
    }

    private boolean isValid() {
        EditText phoneNumber = view.findViewById(R.id.number);
        TextInputLayout t = view.findViewById(R.id.containerNumber);
        if (phoneNumber.getText().toString().length() == 18) {
            t.setError(null);
            return (true);
        } else {
            t.setError("Ошибка");
            return (false);
        }
    }

    public void addImage(Uri uri) {
        images.add(uri);
        inflateImage(uri);
    }

    public void inflateImage(Uri uri) {
        LinearLayout add_image_cont = view.findViewById(R.id.add_image_cont);
        try {
            Bitmap bitmap = MediaStore.Images.Media.getBitmap(a.getContentResolver(), uri);
            View view = a.getLayoutInflater().inflate(R.layout.img, add_image_cont, false);
            add_image_cont.addView(view, 0);
            ImageView img = (ImageView) view;
            img.setImageBitmap(bitmap);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void releaseData() {
        super.releaseData();
        a.setTitle("Новое письмо");
        final EditText nameOfPresent = view.findViewById(R.id.edit_text);
        final EditText letterText = view.findViewById(R.id.letter_text);
        final EditText date = view.findViewById(R.id.date);
        final EditText phoneNumber = view.findViewById(R.id.number);
        LinearLayout add_image_cont = view.findViewById(R.id.add_image_cont);
        for (int i = 0; i < add_image_cont.getChildCount(); i++) {
            if (add_image_cont.getChildAt(i).getId() != R.id.add_image) {
                add_image_cont.removeViewAt(i);
            }
        }
        if (letter != null) {
            for (int i = 0; i < letter.images.size(); i++) {
                Uri uri = Uri.parse(letter.images.get(i));
                inflateImage(uri);
            }
            nameOfPresent.setText(letter.name);
            letterText.setText(letter.text);
            date.setText(a.dateFormat.format(letter.date));
            phoneNumber.setText(letter.number);
        } else {
            nameOfPresent.setText("");
            letterText.setText("");
            date.setText("");
            phoneNumber.setText("");
        }
    }
}
