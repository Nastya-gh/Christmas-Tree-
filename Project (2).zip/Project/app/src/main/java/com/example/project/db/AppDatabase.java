package com.example.project.db;

import androidx.room.Database;
import androidx.room.RoomDatabase;

import com.example.project.dao.LetterDao;
import com.example.project.dao.OrgDao;
import com.example.project.model.Letter;
import com.example.project.model.Organization;

@Database(entities = {Letter.class, Organization.class}, version = 1)
public abstract class AppDatabase extends RoomDatabase {
    public abstract LetterDao getLetterDao();
    public abstract OrgDao getOrgDao();
}

