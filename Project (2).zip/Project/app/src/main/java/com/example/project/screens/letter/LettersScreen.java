package com.example.project.screens.letter;

import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.example.project.MainActivity;
import com.example.project.R;
import com.example.project.adapter.LetterAdapter;
import com.example.project.model.Letter;
import com.example.project.model.Organization;
import com.screen_manager.Screen;

import java.util.ArrayList;
import java.util.stream.Collectors;

import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.Disposable;
import io.reactivex.schedulers.Schedulers;

public class LettersScreen extends Screen {
    MainActivity a = (MainActivity) activity;
    private Organization organizator;
    private TextView organizator_name;
    private TextView organizator_address;
    private TextView organizator_number;
    private RecyclerView recyclerView;
    private LetterAdapter letterAdapter;
    private ImageView icAdd;

    public LettersScreen(ViewGroup parent) {
        super(parent, R.layout.org_screen);
        organizator_name = view.findViewById(R.id.oraganizator_name);
        organizator_address = view.findViewById(R.id.organizator_address);
        organizator_number = view.findViewById(R.id.organizator_number);
        recyclerView = view.findViewById(R.id.recycler_view);
        icAdd = view.findViewById(R.id.add);
        icAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                a.newLetterScreen.letter = null;
                a.manager.setScreen(a.newLetterScreen);
            }
        });

        bindList();
    }

    public void updateAll() {
        Disposable s = a.db.getLetterDao().getAllLetter().subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).subscribe(l -> {
            l = l.stream().filter(it -> it.organizationName.equals(organizator.getName())).collect(Collectors.toList());
            letters = (ArrayList<Letter>) l;
            updateList();
            letterAdapter.notifyDataSetChanged();
        });
    }

    public ArrayList<Letter> letters = new ArrayList<>();

    public void updateList() {
        letterAdapter.letters = letters;
    }

    private void bindList() {
        letterAdapter = new LetterAdapter(letters, v -> {
            int position = recyclerView.getChildAdapterPosition(v);
            Letter l = letterAdapter.letters.get(position);
            a.favoriteLetterScreen.letter = l;
            a.manager.setScreen(a.favoriteLetterScreen);

        }, a);
        recyclerView.setAdapter(letterAdapter);
    }

    public void setOrganizator(Organization organizator) {
        this.organizator = organizator;
    }

    public Organization getOrganizator() {
        return organizator;
    }

    @Override
    protected void releaseData() {
        super.releaseData();
        organizator_name.setText(organizator.getName());
        organizator_address.setText(organizator.getAddress());
        organizator_number.setText(organizator.getPhoneNumber());
        a.setTitle("Организатор");
        updateAll();
    }
}
