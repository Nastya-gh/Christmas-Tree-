package com.example.project.screens.map;

import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.location.Address;
import android.os.AsyncTask;
import android.util.Log;
import android.view.MotionEvent;
import android.view.ViewGroup;
import android.widget.Toast;

import com.example.project.MainActivity;
import com.example.project.R;
import com.example.project.enums.State;
import com.example.project.model.Organization;
import com.example.project.services.GeocoderNominatim;
import com.screen_manager.Screen;

import org.osmdroid.api.IMapController;
import org.osmdroid.tileprovider.MapTileProviderBasic;
import org.osmdroid.tileprovider.tilesource.TileSourceFactory;
import org.osmdroid.util.GeoPoint;
import org.osmdroid.views.CustomZoomButtonsController;
import org.osmdroid.views.MapView;
import org.osmdroid.views.Projection;
import org.osmdroid.views.overlay.ItemizedIconOverlay;
import org.osmdroid.views.overlay.Overlay;
import org.osmdroid.views.overlay.OverlayItem;

import java.util.ArrayList;
import java.util.List;

import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.Disposable;
import io.reactivex.functions.Consumer;
import io.reactivex.schedulers.Schedulers;

import static okhttp3.internal.Util.userAgent;

public class MapScreen extends Screen {
    public static MapView map;
    private final Overlay touchOverlay;
    MainActivity a = (MainActivity) activity;
    public State state = State.NONE;

    public MapScreen(ViewGroup parent) {
        super(parent, R.layout.map_screen);
        map = (MapView) view.findViewById(R.id.map);
        map.setTileSource(TileSourceFactory.MAPNIK);
        map.setMultiTouchControls(true);
        IMapController mapController = map.getController();
        GeoPoint startPoint = new GeoPoint(53.2064419, 50.2060331);
        mapController.setCenter(startPoint);
        mapController.setZoom(10.5);
        map.getZoomController().setVisibility(CustomZoomButtonsController.Visibility.ALWAYS);
        map.getZoomController().activate();

        touchOverlay = new Overlay(activity) {

            @Override
            public void draw(Canvas arg0, MapView arg1, boolean arg2) {
                super.draw(arg0, arg1, arg2);
            }

            @Override
            public boolean onSingleTapUp(MotionEvent e, MapView mapView) {
                Projection proj = mapView.getProjection();
                GeoPoint loc = (GeoPoint) proj.fromPixels((int) e.getX(), (int) e.getY());
                String longitude = Double.toString(loc.getLongitude());
                String latitude = Double.toString(loc.getLatitude());
                System.out.println("- Latitude = " + latitude + ", Longitude = " + longitude);
                new GeocodingTask().execute(loc.getLatitude(), loc.getLongitude());
                return false;
            }
        };
    }

    List<Organization> orgs = new ArrayList<>();

    @Override
    protected void releaseData() {
        super.releaseData();
        if (state == State.SELECT_ORG){
            a.setTitle("Выберите организатора");
        } else if(state == State.SELECT_POINT) {
            a.setTitle("Укажите адрес");
        }
        Disposable s = a.db.getOrgDao().getAll().subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).subscribe(new Consumer<List<Organization>>() {
            @Override
            public void accept(List<Organization> organizations) throws Exception {
                orgs = organizations;
                checkList(orgs);
            }
        });

        map.setTileProvider(new MapTileProviderBasic(activity, TileSourceFactory.MAPNIK));
    }

    private void checkList(List<Organization> orgs) {
        map.getOverlays().clear();
        if (state == State.SELECT_ORG) {
            for (int i = 0; i < orgs.size(); i++) {
                setOrganization(orgs.get(i));
            }
            map.refreshDrawableState();
            map.requestFocus();
            map.getController().setZoom(9.0);
        } else if (state == State.SELECT_POINT) {
            map.getOverlays().add(touchOverlay);
        }
    }

    private class GeocodingTask extends AsyncTask<Object, Void, List<Address>> {

        protected List<Address> doInBackground(Object... params) {
            Double d1 = (Double) params[0];
            Double d2 = (Double) params[1];
            GeocoderNominatim geocoder = new GeocoderNominatim(userAgent);
            geocoder.setOptions(true);
            try {
                List<Address> foundAdresses = geocoder.getFromLocation(d1, d2, 1);
                return foundAdresses;
            } catch (Exception e) {
                return null;
            }
        }

        protected void onPostExecute(List<Address> foundAdresses) {
            if (foundAdresses == null) {
                Toast.makeText(activity, "Geocoding error", Toast.LENGTH_SHORT).show();
            } else if (foundAdresses.size() == 0) { //if no address found, display an error
                Toast.makeText(activity, "Address not found.", Toast.LENGTH_SHORT).show();
            } else {
                Address address = foundAdresses.get(0); //get first address
                String addressDisplayName = address.getExtras().getString("display_name");

                a.orgScreen.setAddress(addressDisplayName, new GeoPoint(address.getLatitude(), address.getLongitude()));
                a.manager.setScreen(a.orgScreen);
            }
        }
    }

    private void setOrganization(final Organization organization) {
        GeoPoint p = organization.getGeoPoint();
        final Drawable marker = activity.getApplicationContext().getResources().getDrawable(R.drawable.icon_org);
        ArrayList<OverlayItem> overlayArray = new ArrayList<>();
        OverlayItem mapItem = new OverlayItem(organization.getName(), organization.getName(), p);
        mapItem.setMarker(marker);
        overlayArray.add(mapItem);
        final ItemizedIconOverlay<OverlayItem> itemizedIconOverlay = new ItemizedIconOverlay<>(activity.getApplicationContext(), overlayArray, new ItemizedIconOverlay.OnItemGestureListener<OverlayItem>() {
            @Override
            public boolean onItemSingleTapUp(int index, OverlayItem item) {
                Log.i("m5", "Вы выбрали организатора");
                map.getOverlays().clear();
                a.lettersScreen.setOrganizator(organization);
                a.manager.setScreen(a.lettersScreen);

                return false;
            }

            @Override
            public boolean onItemLongPress(int index, OverlayItem item) {
                return false;
            }
        });
        map.getOverlays().add(itemizedIconOverlay);
        map.invalidate();
        map.getController().setCenter(p);
    }
}